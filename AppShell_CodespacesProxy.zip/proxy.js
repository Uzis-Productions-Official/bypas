// proxy.js - Full support proxy for AppShell
const express = require("express");
const { createProxyMiddleware } = require("http-proxy-middleware");
const cors = require("cors");

const app = express();
const PORT = process.env.PORT || 8080;

// CORS enabled for dev
app.use(cors());

// Proxy middleware - streams all requests
app.use(
  "/proxy",
  createProxyMiddleware({
    target: "http://example.com", // overwritten per request
    changeOrigin: true,
    selfHandleResponse: false,
    pathRewrite: {
      "^/proxy": "",
    },
    router: (req) => {
      const targetUrl = req.query.url;
      if (!targetUrl) return "http://example.com";
      return targetUrl;
    },
    onProxyRes: (proxyRes, req, res) => {
      // Optionally strip headers that block iframes
      if (process.env.STRIP_FRAME_HEADERS === "true") {
        delete proxyRes.headers["x-frame-options"];
        delete proxyRes.headers["content-security-policy"];
      }
    },
  })
);

app.listen(PORT, () => {
  console.log(`✅ Proxy running on port ${PORT}`);
  console.log(`Use like: http://localhost:${PORT}/proxy?url=https://example.com`);
});
