# AppShell Codespaces Proxy

This is a full-support proxy for AppShell Browser, designed to run inside **GitHub Codespaces**.

## Features
- Works with **HTML, CSS, JS, images, videos, binaries**
- Handles **WebSockets**
- Supports **all HTTP verbs**
- Optionally strips `X-Frame-Options` and `Content-Security-Policy` headers

## Setup in Codespaces

1. Create a new repo (e.g. `appshell-proxy`).
2. Upload this folder to it.
3. Open the repo in **Codespaces**.
4. In terminal, run:

   ```bash
   npm install
   npm start
   ```

5. When Codespaces asks to expose port `8080`, click **Make Public**.
6. Copy the URL it gives you, it will look like:

   ```
   https://<yourid>-8080.app.github.dev/proxy?url=
   ```

7. Add that URL as a proxy option in **AppShell**.

## Auto-start on Codespaces boot

To auto-start the proxy when the Codespace launches:
- Go to `.devcontainer/devcontainer.json`
- Add:

```json
{
  "postCreateCommand": "npm install && npm start"
}
```

Now, every time your Codespace boots, the proxy will start automatically.
