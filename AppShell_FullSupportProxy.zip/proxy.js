/**
 * AppShell Full-Support Proxy
 * -----------------------------------------
 * - Streams ANY content type (HTML, JS, CSS, images, video, binary)
 * - Passes through all HTTP methods (GET/POST/PUT/PATCH/DELETE/etc.)
 * - WebSocket support
 * - CORS enabled (for your local dev)
 * - Optionally strips frame-breaking headers (X-Frame-Options/CSP) — use only for apps you own/control
 * - Rewrites 3xx Location headers so redirects continue through the proxy
 *
 * Usage:
 *   npm i express http-proxy cors
 *   node proxy.js
 *   Then call: http://localhost:8080/proxy?url=https://example.com/path
 *
 * Security notes:
 * - This is for local development/testing. Exposing this to the public internet is risky.
 * - Respect target sites' Terms of Service. Do not bypass protections for sites you don't own/control.
 */
const http = require("http");
const https = require("https");
const express = require("express");
const cors = require("cors");
const { URL } = require("url");
const httpProxy = require("http-proxy");

const app = express();
const PORT = process.env.PORT || 8080;

// -------- Settings (environment-driven) --------
const STRIP_FRAME_HEADERS = (process.env.STRIP_FRAME_HEADERS || "true").toLowerCase() === "true";
// Optional: comma-separated allowed hostnames (empty = allow all for local dev)
const ALLOW_LIST = (process.env.ALLOW_LIST || "").split(",").map(s => s.trim()).filter(Boolean);

// Basic CORS for local dev
app.use(cors({
  origin: true,
  credentials: true,
  allowedHeaders: ["Content-Type", "Authorization", "Range", "Accept", "X-Requested-With"],
  exposedHeaders: ["*"],
}));

// Handle preflight quickly
app.options("*", (req, res) => {
  res.setHeader("Access-Control-Allow-Origin", req.headers.origin || "*");
  res.setHeader("Access-Control-Allow-Credentials", "true");
  res.setHeader("Access-Control-Allow-Methods", "GET,POST,PUT,PATCH,DELETE,HEAD,OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", req.headers["access-control-request-headers"] || "*");
  res.sendStatus(204);
});

// Helpful info route
app.get("/", (req, res) => {
  res.type("text/plain").send([
    "AppShell Full-Support Proxy",
    "-----------------------------------------",
    "Use /proxy?url=https://example.com/path",
    "",
    "Env vars:",
    "  PORT=8080",
    "  STRIP_FRAME_HEADERS=true|false",
    "  ALLOW_LIST=example.com,another.com (empty = allow all)",
  ].join("\n"));
});

// Core proxy instance
const proxy = httpProxy.createProxyServer({
  changeOrigin: true,
  secure: false,            // allow self-signed for dev
  ws: true,                 // WebSocket support
  ignorePath: true,         // we'll pass the full target URL ourselves
  followRedirects: false,   // we'll rewrite Location header manually
});

// On the way back, rewrite headers if needed
proxy.on("proxyRes", (proxyRes, req, res) => {
  // Set permissive CORS in dev
  res.setHeader("Access-Control-Allow-Origin", req.headers.origin || "*");
  res.setHeader("Access-Control-Allow-Credentials", "true");
  res.setHeader("Access-Control-Expose-Headers", "*");

  // Optionally remove frame-breaking headers
  if (STRIP_FRAME_HEADERS) {
    if (proxyRes.headers["x-frame-options"]) delete proxyRes.headers["x-frame-options"];
    if (proxyRes.headers["content-security-policy"]) delete proxyRes.headers["content-security-policy"];
    if (proxyRes.headers["content-security-policy-report-only"]) delete proxyRes.headers["content-security-policy-report-only"];
  }

  // Rewrite 3xx Location to keep redirects going through our proxy
  const status = proxyRes.statusCode || 0;
  if (status >= 300 && status < 400 && proxyRes.headers.location && req.__targetBase) {
    try {
      const loc = new URL(proxyRes.headers.location, req.__targetBase).toString();
      const proxied = `${req.protocol}://${req.headers.host}/proxy?url=${encodeURIComponent(loc)}`;
      proxyRes.headers.location = proxied;
    } catch {
      // best effort; leave as-is if parsing fails
    }
  }
});

proxy.on("error", (err, req, res) => {
  if (!res.headersSent) {
    res.writeHead(502, { "Content-Type": "application/json" });
  }
  res.end(JSON.stringify({ error: "Proxy error", details: err.message }));
});

// Helper to validate and parse target URL
function parseTarget(raw) {
  if (!raw) throw new Error("Missing url parameter");
  let target;
  try {
    target = new URL(raw);
  } catch {
    throw new Error("Invalid URL");
  }
  if (!/^https?:$/.test(target.protocol)) {
    throw new Error("Only http(s) URLs are allowed");
  }
  if (ALLOW_LIST.length && !ALLOW_LIST.includes(target.hostname)) {
    throw new Error("Hostname not allowed by ALLOW_LIST");
  }
  return target.toString();
}

// Main proxy endpoint: /proxy?url=...
app.use("/proxy", (req, res) => {
  const raw = req.query.url || "";
  let target;
  try {
    target = parseTarget(raw);
  } catch (e) {
    return res.status(400).json({ error: e.message });
  }
  req.__targetBase = target;
  proxy.web(req, res, { target });
});

// WebSocket upgrade support on /proxy?url=...
const server = http.createServer(app);
server.on("upgrade", (req, socket, head) => {
  try {
    const urlObj = new URL(req.url, "http://localhost");
    if (urlObj.pathname === "/proxy") {
      const raw = urlObj.searchParams.get("url");
      const target = parseTarget(raw);
      proxy.ws(req, socket, head, { target });
    } else {
      socket.destroy();
    }
  } catch {
    socket.destroy();
  }
});

server.listen(PORT, () => {
  console.log(`✅ Full-Support Proxy running on http://localhost:${PORT}`);
  console.log(`   Example: http://localhost:${PORT}/proxy?url=${encodeURIComponent("https://example.com/")}`);
});
