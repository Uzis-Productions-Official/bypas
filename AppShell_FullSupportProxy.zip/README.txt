AppShell Full-Support Proxy
===========================

What it does
------------
- Streams ANY content type (HTML, CSS, JS, images, audio, video, binary)
- Forwards all HTTP methods (GET/POST/PUT/PATCH/DELETE/etc.)
- Supports WebSockets
- Adds permissive CORS headers for local development
- Optionally removes frame-breaking headers (X-Frame-Options / CSP) — use only for apps you own/control
- Rewrites 3xx Location headers so redirects continue through the proxy

Setup
-----
1) Install Node.js (v16+ recommended).
2) In this folder, run:
   npm i express http-proxy cors
3) Start:
   node proxy.js

Use it
------
- In your AppShell, add a proxy option:
  http://localhost:8080/proxy?url=

- Then opening an app like https://example.com will be requested as:
  http://localhost:8080/proxy?url=https%3A%2F%2Fexample.com

Environment variables
---------------------
- PORT=8080
- STRIP_FRAME_HEADERS=true|false            (default true)
- ALLOW_LIST=example.com,another.com       (empty = allow all)

Security & Legal
----------------
- This proxy is intended for local development only.
- Do not expose it publicly without authentication and rate limits.
- Respect target sites' Terms of Service. Do not bypass protections for sites you don't own/control.
